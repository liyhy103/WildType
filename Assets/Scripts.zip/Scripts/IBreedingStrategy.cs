public interface IBreedingStrategy
{
    Creature Breed(Creature parent1, Creature parent2);
}
