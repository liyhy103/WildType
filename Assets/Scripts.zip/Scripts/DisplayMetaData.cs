using UnityEngine;

public class DisplayMetadata : MonoBehaviour
{
    public string Gender;      
    public string Phenotype;   
    public string BodyColor;   
}
