public static class CreatureTransfer
{
    public static Creature CreatureToAssign;
    public static int TargetParentIndex; 
}
